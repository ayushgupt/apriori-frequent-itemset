g++ aprioriDataMining.cpp -std=c++11 -o 2014CS50281
./2014CS50281 $1 $2
